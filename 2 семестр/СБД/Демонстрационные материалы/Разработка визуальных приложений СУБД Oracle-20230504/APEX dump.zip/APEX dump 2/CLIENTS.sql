--------------------------------------------------------
--  File created - Tuesday-April-28-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CLIENTS
--------------------------------------------------------

  CREATE TABLE CLIENTS 
   (	"NAME" VARCHAR2(255 BYTE), 
	"ID" NUMBER, 
	"GUARD" NUMBER, 
	"AMT" NUMBER
   );

REM INSERTING into MYTEST.CLIENTS
SET DEFINE OFF;
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('IVANOV',5,1,500);
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('PETROV',1,0,20);
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('KUZNETSOV',2,1,10000);
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('SERGEEV',3,1,700);
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('BORISOV',4,1,20000);
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('DMITRIEV',6,0,100);
Insert into CLIENTS (NAME,ID,GUARD,AMT) values ('petrov',null,null,null);
