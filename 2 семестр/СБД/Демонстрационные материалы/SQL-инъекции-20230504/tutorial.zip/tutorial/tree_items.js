/* 
	the format of the tree definition file is simple,
	you can find specification in the Tigra Menu documentation at:
	
	http://www.softcomplex.com/products/tigra_tree_menu/docs/index.html#hierarchy
*/

var TREE_ITEMS = 
[
	['Tutorial Home','html/tutorialhome.htm', 
	   ['Audience and Prerequisites','html/tutorialhome_p3.htm'
		], 
	   ['Using this Tutorial','html/tutorialhome_p2.htm'
		],
       ['1. SQL Injection Overview','html/lesson1/les01_whylearnit.htm',
		   ['1.1 What is SQL Injection?','html/lesson1/les01_tm_ovw.htm'
           ],
		   ['1.2 How can SQL Injection happen?','html/lesson1/les01_tm_ovw_b.htm'
		   ],
		   ['1.3 Types of SQL Injection Attacks','html/lesson1/les01_tm_attacks.htm'
		   ],
		   ['1.4 Avoidance Strategies Against SQL Injection Attacks','html/lesson1/les01_tm_avoid.htm'
           ],
		   ['Lesson 1 Quiz','html/lesson1/les01_si_quiz.htm'
           ]
		],
       ['2. Reducing the Attack Surface','html/lesson2/les02_whylearnit.htm',
		   ['2.1 Expose the database only via PL/SQL API','html/lesson2/les02_tm_API.htm'
           ],
		   ['2.2 Use Invoker\'s\ Rights','html/lesson2/les02_tm_rights.htm'
           ],
		   ['2.3 Reduce Arbitrary Inputs','html/lesson2/les02_tm_inputs.htm'
           ],
		   ['2.4 Strengthen Database Security','html/lesson2/les02_tm_dbsec.htm'
           ],		   
		   ['Lesson 2 Quiz','html/lesson2/les02_si_quiz.htm'
           ]
		],
	   ['3. Avoiding Dynamic SQL','html/lesson3/les03_whylearnit.htm',
		   ['3.1 Use Compile-Time-Fixed SQL Statement','html/lesson3/les03_tm_static1.htm'
           ],
		    ['3.2 Use Static SQL','html/lesson3/les03_tm_static.htm'
           ],
		   ['3.3 What if You Must Use Dynamic SQL?','html/lesson3/les03_tm_options.htm'
           ],
		   ['Lesson 3 Quiz','html/lesson3/les03_si_quiz.htm'
           ]
		],
	    ['4. Using Bind Arguments','html/lesson4/les04_whylearnit.htm',
		   ['4.1 Use Bind Arguments with Dynamic SQL','html/lesson4/les04_tm_sql.htm'
           ],
		   ['4.2 Use Bind Arguments with Dynamic PL/SQL','html/lesson4/les04_tm_plsql.htm'
           ],
		   ['4.3 What if You Cannot Use Bind Arguments?','html/lesson4/les04_tm_options.htm'
           ],
		   ['Lesson 4 Quiz','html/lesson4/les04_si_quiz.htm'
           ]		   
		],
		['5. Filtering Input with DBMS_ASSERT','html/lesson5/les05_whylearnit.htm',
		   ['5.1 Overview of DBMS_ASSERT','html/lesson5/les05_tm_pkg_ovw.htm'
           ],	 
		   ['5.2 Format Oracle Identifiers','html/lesson5/les05_tm_ovw.htm'
           ],
		   ['5.3 Choose a Verification Routine','html/lesson5/les05_tm_usage.htm'
           ],
		   ['5.4 DBMS_ASSERT Usage Guidelines','html/lesson5/les05_tm_bestpractices.htm'
           ],
		   ['5.5 DBMS_ASSERT Limitations','html/lesson5/les05_tm_limitations.htm'
           ],
 		   ['Lesson 5 Quiz','html/lesson5/les05_si_quiz.htm'
           ]		      
		],
        ['6. Designing Code Immune to SQL Injections','html/lesson6/les06_whylearnit.htm',
	 	    ['6.1 Use Bind Arguments','html/lesson6/les06_tm_bindargs.htm'
			 ],
	 	    ['6.2 Handle Oracle Identifiers Carefully','html/lesson6/les06_tm_identifier.htm'
			 ],
			['6.3 Avoid Privilege Escalation','html/lesson6/les06_tm_priv.htm'
			 ],
			['6.4 Beware of "Filter" Parameters','html/lesson6/les06_tm_filter.htm'
			 ],
			['6.5 Trap and Handle Exceptions','html/lesson6/les06_tm_exceptions.htm'
			 ],
		   ['Lesson 6 Quiz','html/lesson6/les06_si_quiz.htm'
           ]		   			
		],
        ['7. Testing Code for SQL Injection Flaws','html/lesson7/les07_whylearnit.htm',
	 	    ['7.1 Code Review and Test Strategy','html/lesson7/les07_tm_ovw.htm'
			 ],
			['7.2 Review Code','html/lesson7/les07_tm_codereview.htm'
			 ],
			['7.3 Run Static Code Analysis','html/lesson7/les07_tm_staticanalysis.htm'
			 ],
            ['7.4 Test with Fuzzing Tools','html/lesson7/les07_tm_fuzzing.htm'
			 ],
            ['7.5 Generate Test Cases','html/lesson7/les07_tm_testing.htm'
			 ],
		   ['Lesson 7 Quiz','html/lesson7/les07_si_quiz.htm'
           ]		   			
        ],
  	['Summary','html/tutorialsummary.htm'
  	 ]
   ]
];