-- Filename: les06_trigger_demo.sql
-- Created: October 2, 2007
-- Creator: Jenny Tsai-Smith
-- Description: Code sample generating Oracle identifiers based
--              on user-supplied identifiers.

CONN / AS sysdba

SET SERVEROUTPUT ON

CREATE TABLE hr.test99
(col1 number, col2 varchar2(200))
/

SELECT object_id, object_name
FROM all_objects
WHERE object_name = 'TEST99'
AND object_type = 'TABLE'
AND owner = 'HR'
/

CREATE OR REPLACE PROCEDURE add_trigger
 (p_schema VARCHAR2,p_table_name VARCHAR2) AS
 stmt VARCHAR2(4000);
 BEGIN
 FOR o IN
   (SELECT object_id FROM all_objects
    WHERE owner=p_schema AND
    object_type='TABLE' AND
    object_name=p_table_name) LOOP
    stmt := 'CREATE OR REPLACE TRIGGER '
              ||sys.dbms_assert.enquote_literal(
            sys.dbms_assert.simple_sql_name(p_schema))
              ||'.'||sys.dbms_assert.enquote_literal('XX$'||o.object_id)
              ||' AFTER UPDATE ON '
              ||sys.dbms_assert.enquote_literal(
                sys.dbms_assert.simple_sql_name(p_schema))
              ||'.'||sys.dbms_assert.enquote_literal(
                sys.dbms_assert.simple_sql_name(p_table_name))
              ||' FOR EACH ROW Begin NULL; End;';
    DBMS_OutPut.Put_Line('SQL stmt: ' || stmt);
    EXECUTE IMMEDIATE stmt;
 END LOOP;
 EXCEPTION WHEN OTHERS THEN
   RAISE;
 END;
 /

EXEC sys.add_trigger('HR','TEST99')

SELECT object_id, object_name
FROM all_objects
WHERE object_type = 'TRIGGER'
AND object_name like 'XX%'
AND owner = 'HR'
/

DROP TABLE hr.test99
/
