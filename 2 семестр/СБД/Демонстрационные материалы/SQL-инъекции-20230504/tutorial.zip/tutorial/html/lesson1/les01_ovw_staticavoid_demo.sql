-- Filename: les01_ovw_attack_demo.sql
-- Created: October 2, 2007
-- Creator: Bryn Llewellyn (adapted by Jenny Tsai-Smith)
-- Description: Code sample with static SQL.
--              Used to demonstrate SQL injection avoidance.

-- Connect as HR in at least 10.2 before running this SQL*Plus script.

CONN hr

SET SERVEROUTPUT ON

CREATE OR REPLACE
PROCEDURE User_Login 
          (p_Email      Employees.Email%type      DEFAULT NULL,
           p_Last_Name  Employees.Last_Name%type  DEFAULT NULL)
AS
  v Employees.Email%type;
BEGIN
  SELECT  Email
  INTO    v
  FROM    Employees
  WHERE   Email = p_Email
  AND     Last_Name = p_Last_Name;

  DBMS_Output.Put_Line ('Logon succeeded.');

EXCEPTION WHEN OTHERS THEN
  Raise_Application_Error(-20000, 'Logon failed.');

END User_Login;
/

EXEC User_Login('PFAY','Fay')

EXEC User_Login('PFAY','bad lastname')

EXEC User_Login(''' or 1=1 and Rownum=1 --','somelastname')

-- Add more data designed to test functional bugs 
-- that were in the code with dynamic SQL and string concatenation.
BEGIN
  INSERT INTO Employees
    (Employee_ID, Last_Name, Email, Hire_Date, Job_ID)
  VALUES (9000, 'O''Hara', 'POHARA', Sysdate, 'ST_MAN');

  INSERT INTO Employees
    (Employee_ID, Last_Name, Email, Hire_Date, Job_ID)
  VALUES (9001, '''Weird', 'w', Sysdate, 'ST_MAN');

  INSERT INTO Employees
    (Employee_ID, Last_Name, Email, Hire_Date, Job_ID)
  VALUES (9002, '''', 'q', Sysdate, 'ST_MAN');

END;
/

-- No longer a bug
EXEC User_Login('POHARA','O''Hara')

-- No longer a bug
EXEC  User_Login('w','''Weird')

-- No longer a bug
EXEC User_Login('q','''')

-- Logon will fail because of trailing space
EXEC  User_Login('PFAY ','Fay')


CREATE OR REPLACE
FUNCTION To_Whitespace_Trimmed(i IN VARCHAR2) 
RETURN VARCHAR2 
AS
  Space CONSTANT CHAR(1) := ' ';
  Newline CONSTANT CHAR(1) := '
';
  Tab CONSTANT CHAR(1) := Chr(9);
  TYPE t IS TABLE OF VARCHAR2(10);
  -- This is just an illustration; there may be others.
  Whitespace_Characters CONSTANT t := t(Space, Newline, Tab);

  v VARCHAR2(32767) := i;
BEGIN
  DECLARE
    Cur_Length  PLS_INTEGER := Length(v);
    Prev_Length PLS_INTEGER := Cur_Length + 1;
  BEGIN
    WHILE Cur_Length < Prev_Length LOOP
      Prev_Length := Cur_Length;
      FOR j IN 1..Whitespace_Characters.Count() LOOP
        v := Trim(BOTH Whitespace_Characters(j) FROM v);
      END LOOP;
      Cur_Length := Length(v);
    END LOOP;
  END;
  RETURN v;
END To_Whitespace_Trimmed;
/

CREATE OR REPLACE
PROCEDURE User_Login 
          (p_Email      Employees.Email%type      DEFAULT NULL,
           p_Last_Name  Employees.Last_Name%type  DEFAULT NULL)
AS
  v Employees.Email%type;
BEGIN
  SELECT  Email
  INTO    v
  FROM    Employees
  WHERE   Email = To_Whitespace_Trimmed(p_Email)
  AND     Last_Name = To_Whitespace_Trimmed(p_Last_Name);

  DBMS_Output.Put_Line ('Logon succeeded.');

EXCEPTION WHEN OTHERS THEN
  Raise_Application_Error(-20000, 'Logon failed.');

END User_Login;
/

-- No longer a bug
EXEC  User_Login('PFAY ','Fay')


-- Remove the records that were inserted for testing the code function.
DELETE Employees
WHERE Employee_ID > = 9000
/
