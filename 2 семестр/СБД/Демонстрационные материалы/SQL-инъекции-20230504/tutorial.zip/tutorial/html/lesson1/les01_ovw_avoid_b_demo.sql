-- Filename: les01_ovw_avoid_b_demo.sql
-- Created: January 30, 2009
-- Creator: Tulika Srivastava
-- Description: Code sample with dynamic SQL and string concatenation.
--              Used to demonstrate SQL injection vulnerability.

-- Connect as HR in at least 10.2 before running this SQL*Plus script.

CONN hr/hr

SET SERVEROUTPUT ON

CREATE OR REPLACE
PROCEDURE show_col2 (p_colname varchar2, p_tablename   varchar2)
AS
type t is varray(200) of varchar2(25);
Results t;

  Stmt CONSTANT VARCHAR2(4000) :=
    'SELECT '||dbms_assert.simple_sql_name( p_colname ) || ' FROM '|| dbms_assert.simple_sql_name( p_tablename ) ;

BEGIN
  DBMS_Output.Put_Line ('SQL Stmt: ' || Stmt);
  EXECUTE IMMEDIATE Stmt bulk collect into Results;
for j in 1..Results.Count() loop
DBMS_Output.Put_Line(Results(j));
end loop;
--EXCEPTION WHEN OTHERS THEN
  --Raise_Application_Error(-20000, 'Wrong table name');
END show_col2;
/


execute show_col2('Email','EMPLOYEES');
execute show_col2('Email','EMP');
execute show_col2('Email','EMPLOYEES where 1=2 union select Username c1 from All_Users --');