-- Filename: les01_first_order_attack_demo.sql
-- Created: July 30, 2007
-- Creator: Jenny Tsai-Smith
-- Description: Code sample with dynamic SQL and string concatenation.
--              Used to demonstrate 1st order attack via UNION.


conn hr

set serveroutput on


-- This is the procedure with dynamic SQL constructed 
-- via concatenation of input value.
-- Vulnerable to SQL injection!!

CREATE OR REPLACE
PROCEDURE GET_PHONE (p_email VARCHAR2 DEFAULT NULL)
AS
TYPE cv_emptyp IS REF CURSOR;
cv   cv_emptyp;
v_phone employees.phone_number%TYPE;
v_stmt  VARCHAR2(400);
BEGIN
  v_stmt := 'SELECT phone_number FROM employees WHERE email = ''' 
            || p_email || '''';
            
  DBMS_OUTPUT.PUT_LINE('SQL statement: ' || v_stmt);
  OPEN cv FOR v_stmt;
  LOOP
      FETCH cv INTO v_phone;
      EXIT WHEN cv%NOTFOUND;
      DBMS_OUTPUT.PUT_LINE('Phone: '||v_phone);
  END LOOP;
  CLOSE cv;

EXCEPTION WHEN OTHERS THEN
   dbms_output.PUT_LINE(sqlerrm);
   dbms_output.PUT_LINE('SQL statement: ' || v_stmt);
END;
/

exec get_phone('PFAY')

exec get_phone('x'' union select username from all_users where ''x''=''x')

-- This is the procedure with static SQL
-- Safe from SQL injection!!

CREATE OR REPLACE
PROCEDURE GET_PHONE (p_email VARCHAR2 DEFAULT NULL)
AS

BEGIN

FOR i IN
  (SELECT phone_number 
   FROM employees 
   WHERE email = p_email)
  LOOP
      DBMS_OUTPUT.PUT_LINE('Phone: '||i.phone_number);
  END LOOP;

END;
/

exec get_phone('PFAY')

exec get_phone('x'' union select username from all_users where ''x''=''x')