-- Filename: les05_identifier_demo.sql
-- Created: October 2, 2007
-- Creator: Jenny Tsai-Smith
-- Description: Code sample with SQL injection vulnerability via dynamic SQL
--              concatenated identifier in dynamic SQL.

CONN hr

SET SERVEROUTPUT ON


CREATE TABLE important_table
AS SELECT * FROM employees
/

CREATE OR REPLACE FUNCTION evil_function
RETURN NUMBER
AS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  EXECUTE IMMEDIATE 'delete important_table';
  COMMIT;
RETURN 1;
END;
/

CREATE TABLE "dual where 1=evil_function"
(col1 NUMBER)
/

CREATE OR REPLACE PROCEDURE count_records
AS
   cnt NUMBER;
   stmt VARCHAR2(2000);
BEGIN
   FOR tablenamerec IN (SELECT table_name 
                        FROM all_tables WHERE owner=user
                        ORDER BY table_name) loop
 
      stmt := 'select count (*) from '||tablenamerec.table_name;
      dbms_output.put_line(stmt);
      EXECUTE IMMEDIATE stmt INTO cnt;
      dbms_output.put_line('There are: '||cnt||' records in '
                           ||tablenamerec.table_name);
 
   end loop;
EXCEPTION WHEN OTHERS THEN
   RAISE; 
end;
/

SELECT count(*) FROM important_table
/

EXEC count_records

SELECT count(*) FROM important_table
/

DROP TABLE important_table
/

CREATE TABLE important_table
AS SELECT * FROM employees
/

SELECT count(*) FROM important_table
/

CREATE OR REPLACE PROCEDURE count_records
AS
   cnt NUMBER;
   stmt VARCHAR2(2000);
BEGIN
   FOR tablenamerec IN (SELECT table_name 
                        FROM all_tables WHERE owner=user
                        ORDER BY table_name) loop
 
      stmt := 'select count (*) from '
              ||sys.dbms_assert.enquote_name(
                                tablenamerec.table_name, FALSE);
      dbms_output.put_line(stmt);
      EXECUTE IMMEDIATE stmt INTO cnt;
      dbms_output.put_line('There are: '||cnt||' records in '
                           ||tablenamerec.table_name);
 
   end loop;
EXCEPTION WHEN OTHERS THEN
   RAISE; 
end;
/

EXEC count_records

SELECT count(*) FROM important_table
/

DROP TABLE important_table
/

DROP FUNCTION evil_function
/

DROP TABLE "dual where 1=evil_function"
/

