-- Filename: les01_second_order_attack_demo.sql
-- Created: August 22, 2007
-- Creator: Howard Smith
-- Description: Code sample to show second order SQL injection attack.

-- Create a table to hold audit records recording when objects are created
-- in the schema.

conn hr

SET ECHO ON

DROP TRIGGER audit_trigger
/

DROP TABLE auditcreates
/

DROP TABLE safetable
/

DROP TABLE "Bogus')--table name"
/

CREATE TABLE auditcreates(
    createtime DATE,
    object_type VARCHAR2(32),
    object_name VARCHAR2(32)
)
/


-- Create a trigger to record the audit events

CREATE OR REPLACE TRIGGER audit_trigger AFTER CREATE ON SCHEMA
DECLARE

   stmt VARCHAR2(2000);

BEGIN

   -- Record the creation in the audit trail

   stmt := 'INSERT INTO auditcreates VALUES(SYSDATE,'''||
                   dictionary_obj_type||''','''||
                   dictionary_obj_name||''')';

   EXECUTE IMMEDIATE stmt;               

END;
/

-- This is a safe example illustrating that the trigger works

CREATE TABLE safetable(col1 NUMBER)
/

SELECT * FROM auditcreates
/

-- we can now try and inject into the trigger with a bogus table name

CREATE TABLE "Bogus')--table name"(col1 NUMBER)
/

-- see that the full table name has been hidden from the audit trail? 
SELECT * FROM auditcreates
/

SELECT table_name FROM user_tables
ORDER BY table_name
/


-- Create a trigger to record the audit events

CREATE OR REPLACE TRIGGER audit_trigger AFTER CREATE ON SCHEMA
DECLARE

   stmt VARCHAR2(2000);

BEGIN

   -- Record the creation in the audit trail

   stmt := 'INSERT INTO auditcreates VALUES(SYSDATE,:obj_type,:obj_name)';

   EXECUTE IMMEDIATE stmt
   USING dictionary_obj_type,dictionary_obj_name;               

END;
/

CREATE TABLE "Bogus2')--table name"(col1 NUMBER)
/

SELECT * FROM auditcreates
/

SELECT table_name FROM user_tables
ORDER BY table_name
/
