-- Filename: les01_ovw_attack_demo.sql
-- Created: October 2, 2007
-- Creator: Bryn Llewellyn (adapted by Jenny Tsai-Smith)
-- Description: Code sample with dynamic SQL and string concatenation.
--              Used to demonstrate SQL injection vulnerability.

-- Connect as HR in at least 10.2 before running this SQL*Plus script.

CONN hr

SET SERVEROUTPUT ON

CREATE OR REPLACE
PROCEDURE User_Login 
          (p_Email      Employees.Email%type      DEFAULT NULL,
           p_Last_Name  Employees.Last_Name%type  DEFAULT NULL)
AS

  Stmt CONSTANT VARCHAR2(4000) :=
    'SELECT  Email 
     FROM    Employees
     WHERE   Email = ''' || p_Email ||
     ''' AND    Last_Name = ''' || p_Last_Name || '''';

  v Employees.Email%type;
BEGIN

  DBMS_Output.Put_Line ('SQL Stmt: ' || Stmt);

  EXECUTE IMMEDIATE Stmt 
  INTO v;

  DBMS_Output.Put_Line ('Logon succeeded.');

EXCEPTION WHEN OTHERS THEN
  Raise_Application_Error(-20000, 'Logon failed.');

END User_Login;
/

EXEC User_Login('PFAY','Fay')

EXEC User_Login('PFAY','bad lastname')

EXEC User_Login(''' or 1=1 and Rownum=1 --','somelastname')


-- Add more data designed to reveal functional bugs in the code.
BEGIN
  INSERT INTO Employees
    (Employee_ID, Last_Name, Email, Hire_Date, Job_ID)
  VALUES (9000, 'O''Hara', 'POHARA', Sysdate, 'ST_MAN');

  INSERT INTO Employees
    (Employee_ID, Last_Name, Email, Hire_Date, Job_ID)
  VALUES (9001, '''Weird', 'w', Sysdate, 'ST_MAN');

  INSERT INTO Employees
    (Employee_ID, Last_Name, Email, Hire_Date, Job_ID)
  VALUES (9002, '''', 'q', Sysdate, 'ST_MAN');

END;
/

-- Logon will fail because of trailing space
EXEC  User_Login('PFAY ','Fay')

-- Logon will failed because did'nt expect legal embedded single quote.
EXEC User_Login('POHARA','O''Hara')


-- Logon will fail because did'nt expect legal leading single quote.
EXEC  User_Login('w','''Weird')

-- Logon will fail because did'nt expect legal singleton single quote.
EXEC User_Login('q','''')

-- Remove the records that were inserted for testing the code function.
ROLLBACK
/

