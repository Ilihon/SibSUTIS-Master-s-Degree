-- Filename: les02_invoker_demo.sql
-- Created: July 30, 2007
-- Creator: Jenny Tsai-Smith
-- Description: Code sample using AUTHID CURRENT_USER to
--              execute code with invoker's rights.

-- Procedure that uses definer's rights
CREATE OR REPLACE
PROCEDURE change_password(p_username VARCHAR2 DEFAULT NULL,
                         p_new_password VARCHAR2 DEFAULT NULL)
IS
  v_sql_stmt VARCHAR2(500);
BEGIN
    v_sql_stmt := 'ALTER USER '||p_username ||' IDENTIFIED BY '
                  || p_new_password;

    EXECUTE IMMEDIATE v_sql_stmt;
END change_password;
/

-- Procedure that uses invoker's rights
CREATE OR REPLACE
PROCEDURE change_password(p_username VARCHAR2 DEFAULT NULL,
                         p_new_password VARCHAR2 DEFAULT NULL)
AUTHID CURRENT_USER
IS
  v_sql_stmt VARCHAR2(500);
BEGIN
    v_sql_stmt := 'ALTER USER '||p_username ||' IDENTIFIED BY '
                  || p_new_password;

    EXECUTE IMMEDIATE v_sql_stmt;
END change_password;
/

