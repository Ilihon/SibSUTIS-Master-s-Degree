-- Filename: les04_plsql_demo.sql
-- Created: September 11, 2007
-- Creator: Jenny Tsai-Smith
-- Description: Code sample to demonstrate SQl injection through dynamic PL/SQL block
-- 

Conn hr

SET SERVEROUTPUT ON

--
-- Code contains SQL injection vulnerability
--
CREATE OR REPLACE FUNCTION get_avg_salary (p_job VARCHAR2)
RETURN NUMBER
AS
avgsal employees.salary%TYPE;
v_blk VARCHAR2(4000);

BEGIN
v_blk := 'BEGIN SELECT AVG(salary) INTO :avgsal 
           FROM hr.employees
           WHERE job_id = '''||P_JOB||'''; END;';

EXECUTE IMMEDIATE v_blk
USING OUT avgsal;

dbms_output.put_line('Code: ' || v_blk);

RETURN avgsal;
END;
/

exec dbms_output.put_line('Average salary is ' ||get_avg_salary('SH_CLERK'))


SELECT salary FROM employees WHERE email = 'PFAY'
/

exec dbms_output.put_line('Average salary is ' ||get_avg_salary('SH_CLERK''; UPDATE hr.employees SET salary=4500 WHERE email=''PFAY''; END;--'))


SELECT salary FROM employees WHERE email = 'PFAY'
/

ROLLBACK
/

--
-- Code safe from SQL injection vulnerability
--

CREATE OR REPLACE FUNCTION get_avg_salary (p_job VARCHAR2)
RETURN NUMBER
AS
avgsal employees.salary%TYPE;
v_blk VARCHAR2(4000);

BEGIN
v_blk := 'BEGIN SELECT AVG(salary) INTO :avgsal 
           FROM hr.employees
           WHERE job_id = :p_job; END;';

EXECUTE IMMEDIATE v_blk
USING OUT avgsal, IN p_job;

dbms_output.put_line('Code: ' || v_blk);

RETURN avgsal;
END;
/

exec dbms_output.put_line('Average salary is ' ||get_avg_salary('SH_CLERK'))


SELECT salary FROM employees WHERE email = 'PFAY'
/

exec dbms_output.put_line('Average salary is ' ||get_avg_salary('SH_CLERK''; UPDATE hr.employees SET salary=4500 WHERE email=''PFAY''; END;--'))


SELECT salary FROM employees WHERE email = 'PFAY'
/