-- Filename: les03_like_demo.sql
-- Created: September 11, 2007
-- Creator: Jenny Tsai-Smith
-- Description: Static SQL code sample for handling LIKE operators
--              in query condition.


CONN oe

SET SERVEROUTPUT ON

CREATE OR REPLACE
PROCEDURE list_products_dynamic (p_product_name VARCHAR2 DEFAULT NULL)
AS

TYPE cv_prodtyp IS REF CURSOR;
cv   cv_prodtyp;
v_prodname products.product_name%TYPE;
v_minprice products.min_price%TYPE;
v_listprice products.list_price%TYPE;
v_stmt  VARCHAR2(400);

BEGIN

v_stmt := 'SELECT product_name, min_price, list_price FROM products
           WHERE product_name like ''%'||p_product_name||'%''';

  OPEN cv FOR v_stmt;
dbms_output.put_line(v_stmt);
  LOOP
      FETCH cv INTO v_prodname, v_minprice, v_listprice;
      EXIT WHEN cv%NOTFOUND;
      DBMS_OUTPUT.PUT_LINE('Product Info: '||v_prodname ||', '||
                            v_minprice ||', '|| v_listprice);
  END LOOP;
  CLOSE cv;
END;
/

EXEC list_products_dynamic('Laptop')

EXEC list_products_dynamic(''' and 1=0 union select cast(username as nvarchar2(100)), null, null from all_users --')

CREATE OR REPLACE
PROCEDURE list_products_static (p_product_name VARCHAR2 DEFAULT NULL)
AS

v_bind  VARCHAR2(400);

BEGIN
  v_bind := '%'||p_product_name||'%';
 
  FOR i in 
  (SELECT product_name, min_price, list_price FROM products
             WHERE product_name like v_bind)

  LOOP
      DBMS_OUTPUT.PUT_LINE('Product Info: '||i.product_name ||', '||
                            i.min_price ||', '|| i.list_price);
  END LOOP;
END;
/

EXEC list_products_static('Laptop')

EXEC list_products_static(''' and 1=0 union select cast(username as nvarchar2(100)), null, null from all_users --')
