select * from employees

--group by
SELECT first_name, department_id,
COUNT(*) DEPT_COUNT
from employees
WHERE department_id IN (20, 30)
GROUP BY department_id;

--over partition
SELECT employee_id, first_name, department_id, 
COUNT(*) OVER (PARTITION BY 
department_id order by first_name) DEPT_COUNT
from employees
WHERE department_id IN (20, 30);

--empty over()
SELECT employee_id, department_id,  
COUNT(*) OVER ( ) CNT
from employees
WHERE department_id IN (10, 20)
ORDER BY 2, 1;

SELECT COUNT(*) from employees
WHERE department_id IN (10, 20);

--rownumber 
SELECT employee_id, department_id, hire_date,
ROW_NUMBER( ) OVER (PARTITION BY
department_id ORDER BY hire_date 
NULLS LAST) SRLNO
from employees
--WHERE department_id  IN (10, 20)
--ORDER BY department_id, hire_date desc;

--������ order by?

--rank and dense_rank
SELECT employee_id, department_id, salary,
RANK() OVER (PARTITION BY department_id
ORDER BY salary DESC NULLS LAST) RANK,
DENSE_RANK() OVER (PARTITION BY
department_id ORDER BY salary DESC NULLS
LAST) DENSE_RANK
from employees
--WHERE department_id IN (10, 20)
ORDER BY 2, RANK;


--lead lag
SELECT employee_id, department_id, salary,
LEAD(salary, 1, 0) OVER (PARTITION BY department_id ORDER BY salary DESC NULLS LAST) NEXT_LOWER_SAL,
LAG(salary, 1, 0) OVER (PARTITION BY department_id ORDER BY salary DESC NULLS LAST) PREV_HIGHER_SAL
from employees
--WHERE department_id IN (10, 20)
ORDER BY department_id, salary DESC;

-- How many days after the first hire of each department were the next
-- employees hired?


SELECT employee_id, department_id, hire_date, hire_date - FIRST_VALUE(hire_date)
OVER (PARTITION BY department_id ORDER BY hire_date) DAY_GAP
from employees
WHERE department_id IN (20, 30)
ORDER BY department_id, DAY_GAP;


-- KEEP FIRST LAST
-- How each employee's salary compare with the average salary of the first
-- year hires of their department?

SELECT employee_id, department_id, TO_CHAR(hire_date,'YYYY') HIRE_YR, salary,
TRUNC(
AVG(salary) KEEP (DENSE_RANK FIRST
ORDER BY TO_CHAR(hire_date,'YYYY') )
OVER (PARTITION BY department_id)
     ) AVG_SAL_YR1_HIRE
from employees
--WHERE department_id IN (20, 10)
ORDER BY employee_id, department_id, HIRE_YR;

-- ROW WINDOW
SELECT employee_id, department_id, TO_CHAR(hire_date, 'YYYY') YEAR,
COUNT(*) OVER (PARTITION BY TO_CHAR(hire_date, 'YYYY')
ORDER BY hire_date ROWS BETWEEN 3 PRECEDING AND 1 FOLLOWING) FROM_P3_TO_F1,
COUNT(*) OVER (PARTITION BY TO_CHAR(hire_date, 'YYYY')
ORDER BY hire_date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) FROM_PU_TO_C,
COUNT(*) OVER (PARTITION BY TO_CHAR(hire_date, 'YYYY')
ORDER BY hire_date ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING) FROM_P2_TO_P1,
COUNT(*) OVER (PARTITION BY TO_CHAR(hire_date, 'YYYY')
ORDER BY hire_date ROWS BETWEEN 1 FOLLOWING AND 3 FOLLOWING) FROM_F1_TO_F3
from employees
ORDER  BY hire_date

--1994

--RANGE WINDOW

-- For each employee give the count of employees getting half more that their 
-- salary and also the count of employees in the departments 20 and 30 getting half 
-- less than their salary.
 
SELECT department_id, employee_id, salary,
Count(*) OVER (PARTITION BY department_id ORDER BY salary RANGE
BETWEEN UNBOUNDED PRECEDING AND (salary/2) PRECEDING) CNT_LT_HALF,
COUNT(*) OVER (PARTITION BY department_id ORDER BY salary RANGE
BETWEEN (salary/2) FOLLOWING AND UNBOUNDED FOLLOWING) CNT_MT_HALF
from employees
WHERE department_id IN (20, 30)
ORDER BY department_id, salary



-- For each employee give the count of employees getting half more that their 
-- salary and also the count of employees in the departments 20 and 30 getting half 
-- less than their salary.
 
SELECT employee_id, department_id, salary,
Count(*) OVER (PARTITION BY department_id ORDER BY salary desc  RANGE
BETWEEN UNBOUNDED PRECEDING AND (salary/2) PRECEDING) CNT_LT_HALF,
COUNT(*) OVER (PARTITION BY department_id ORDER BY   salary  desc RANGE
BETWEEN (salary/2) FOLLOWING AND UNBOUNDED FOLLOWING) CNT_MT_HALF
from employees
WHERE department_id IN (20, 30)
ORDER BY department_id, salary -- desc


--asc desc behaviour defference // search direction
select * from employees for update
--difference

SELECT last_name, hire_date, salary,
SUM(salary)
OVER (ORDER BY hire_date
ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) rows_sal,
SUM(salary)
OVER (ORDER BY hire_date
RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) range_sal
from employees;

select * from employees

-- quiz
select department_id, count(*) over
()
from employees
group by department_id




SELECT employee_id, department_id, TO_CHAR(hire_date, 'YYYY') YEAR,
COUNT(*) OVER (PARTITION BY TO_CHAR(hire_date, 'YYYY')
ORDER BY hire_date ROWS  3 PRECEDING) FROM_P3_TO_F1

from employees
ORDER  BY hire_date








